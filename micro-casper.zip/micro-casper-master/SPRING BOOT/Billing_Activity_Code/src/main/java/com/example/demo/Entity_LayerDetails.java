package com.example.demo;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;

import java.lang.reflect.Type;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.datastax.driver.core.querybuilder.Insert;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.datastax.driver.core.querybuilder.Select;
//import com.example.entity.layer.Entity_Layer;
//import com.example.entity.layer.entityLayerRepository;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.google.gson.Gson;
import com.google.gson.JsonElement;

import com.google.gson.reflect.TypeToken;

//import com.example.entity.layer.Entity_Layer;


@Service
public class Entity_LayerDetails {
	@Autowired
	private entityLayerRepository cassandraTemplate;

		@SuppressWarnings({ "unchecked", "deprecation" })
		public String manage(String data) throws JSONException {
			try {
				
				//create ObjectMapper instance
				ObjectMapper objectMapper = new ObjectMapper();
				
				Gson gson = new Gson();
				JSONObject root=new JSONObject(data);
				JSONObject childroot=new JSONObject();

				childroot=(JSONObject) root.get("AREActivityCode");
				
				
				System.out.println("VVVVVVVVVVVVVVVVvVVVVVVVVVVVVVVVVVVVVVVVVVV"+childroot);
				//convert json file to map
				Map<?, ?> map = objectMapper.readValue(childroot.toString(), Map.class);
				
				Map<String, String> temp = new HashMap<>();
				temp.put("ActivityGroup","activity_group");
				temp.put("Code","activity_code");
				temp.put("Cost","cost");
				temp.put("Currency","currency");
				temp.put("Name","activity_name");
				temp.put("TrackType","activity_track_type");
				temp.put("TransactionType","transaction_type");
				temp.put("UOM","unit_of_measure");
				
				String JSON="{\n";
				for(Object key : map.keySet())
				{
						if(temp.containsKey(key)){
							JSON+="\""+temp.get(key)+"\": \""+map.get(key)+"\",\n";
						}
				}
				System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa***********************"+ JSON);
				System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#####################"+ map.get("Code"));
				Map<String,String> act = new HashMap<String, String>();
				act.put("activity_code", (String) map.get("Code"));
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSZ");
			    Date date = new Date();
			    String ts=dateFormat.format(date);
				List<BussinessLayerTableDetails> list=entityLayerRepository.find(act);
				 
				int i=list.size();
				if(i==0){
					JSON+="\"createts\": \""+ts+"\",\n";
					JSON+="\"modifyts\": \""+ts+"\"\n";
				}
				else {
					JSON+="\"modifyts\": \""+ts+"\"\n";
				}
				JSON+="}";
				
				BussinessLayerTableDetails table=objectMapper.readValue(JSON, BussinessLayerTableDetails.class);
				
				BussinessLayerTableDetails insert = cassandraTemplate.insert(table);
				
				
				 
				String json = gson.toJson(insert);
				
				json="{\r\n" + 
						" \"AREActivityCodeList\": {\r\n" + 
						"        \"AREActivityCode\": "+ 
						json+
						"   }\r\n" + 
						"}";

				
				return json;
				
				}
				catch (JsonParseException e)
		        {
		            e.printStackTrace();
		        } catch (JsonMappingException e)
		        {
		            e.printStackTrace();
		        } catch (IOException e)
		        {
		            e.printStackTrace();
		        }
			return null;
		}
		
		public List<BussinessLayerTableDetails> select(String data) throws JsonMappingException, JsonProcessingException {
	           
            //create ObjectMapper instance
            ObjectMapper objectMapper = new ObjectMapper();
           
            //convert json file to map
            Map<?, ?> map = objectMapper.readValue(data, Map.class);
           
            List<BussinessLayerTableDetails> sample=entityLayerRepository.find(map);
            return sample;
		}
		
		
		@SuppressWarnings("unchecked")
		public String list(String data) throws JSONException {
			try {
				
				//create ObjectMapper instance
				ObjectMapper objectMapper = new ObjectMapper();
				
				Gson gson = new Gson();
				JSONObject root=new JSONObject(data);
				JSONObject childroot=new JSONObject();

				childroot=(JSONObject) root.get("AREActivityCode");
				
				System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAA"+data);
				//convert json file to map
				Map<?, ?> newmap = objectMapper.readValue(childroot.toString(), Map.class);
				
				System.out.println("1:"+newmap);
				Map<String, String> map = new HashMap<String,String>();
				//String select = gson.toJson(newmap);
				for(Object key : newmap.keySet())
				{
					if(newmap.get(key)!="" && newmap.get(key)!=null) {
						map.put(key.toString(),newmap.get(key).toString());
					}
				}
				
				//childroot.
				Map<String, String> temp = new HashMap<>();
				temp.put("ActivityGroup","activity_group");
				temp.put("Code","activity_code");
				temp.put("Cost","cost");
				temp.put("Currency","currency");
				temp.put("Name","activity_name");
				temp.put("TrackType","activity_track_type");
				temp.put("TransactionType","transaction_type");
				temp.put("UOM","unit_of_measure");
				
				int l=map.size();
				System.out.println("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"+l);
				
				String JSON="{\n";
				for(Object key : temp.keySet())
				{
					System.out.println("rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr"+temp.get(key)+"BBBB"+map.get(key));
						if(temp.containsKey(key) && map.get(key)!="" && map.get(key)!=null){
							if(l>1) {
								JSON+="\""+temp.get(key)+"\": \""+map.get(key)+"\",\n";
								System.out.println("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"+JSON);
							}
							else {
								JSON+="\""+temp.get(key)+"\": \""+map.get(key)+"\"\n";
								System.out.println("TTTTTTTTTTTTTTTTTTTTTTTTTTTT"+JSON);
							}
						}
						l--;
				}
				
				JSON+="}";
				System.out.println("dadasdwasdsadasdasdasdaddadassaada"+JSON);
				
				Map<?, ?> list = objectMapper.readValue(JSON, Map.class);
				
				System.out.println("dadasdwasdsadasdasdasdaddadassaada"+JSON);
				
				List<BussinessLayerTableDetails> sample=entityLayerRepository.find(list);
				
				System.out.println("VVVVVVVVVVVVVVVVvVVVVVVVVVVVVVVVVVVVVVVVVVV"+childroot);
				 
				String json = gson.toJson(sample);
				
				json="{\r\n" + 
						" \"AREActivityCodeList\": {\r\n" + 
						"        \"AREActivityCode\": "+ 
						json+
						"   }\r\n" + 
						"}";

				
				return json;
				
				}
				catch (JsonParseException e)
		        {
		            e.printStackTrace();
		        } catch (JsonMappingException e)
		        {
		            e.printStackTrace();
		        } catch (IOException e)
		        {
		            e.printStackTrace();
		        }
			return null;
		}
		
		
//		
//		
//		public BussinessLayerTableDetails insert(final BussinessLayerTableDetails data)
//		{	
//			return cassandraTemplate.insert(data);
//		}
//
//		public void deleteAll() {
//			cassandraTemplate.deleteAll();
//		}
//		
//		public List<BussinessLayerTableDetails> findAll() {
//		    return  cassandraTemplate.findAll();
//		    }
//		
//		public List<BussinessLayerTableDetails> find(final BussinessLayerTableDetails data) {
//		    List<BussinessLayerTableDetails> list = new ArrayList<>();
//		    cassandraTemplate.findAll().forEach(e -> list.add(e));
//		    return list;
//		    }
//		
		public String XMLtoJSON(String data) {
			try {
				
				
				// Create a new XmlMapper to read XML tags
	            XmlMapper xmlMapper = new XmlMapper();
	            
	            //Reading the XML
	            JsonNode jsonNode = xmlMapper.readTree(data.getBytes());
	            
	            //Create a new ObjectMapper
	            ObjectMapper objectMapper = new ObjectMapper();
	            
	            //Get JSON as a string
	            String value = objectMapper.writeValueAsString(jsonNode);
	            
	            return value;
				
			}
			catch (JsonParseException e)
	        {
	            e.printStackTrace();
	        } catch (JsonMappingException e)
	        {
	            e.printStackTrace();
	        } catch (IOException e)
	        {
	            e.printStackTrace();
	        }
			return data;
		}
		
		
}
