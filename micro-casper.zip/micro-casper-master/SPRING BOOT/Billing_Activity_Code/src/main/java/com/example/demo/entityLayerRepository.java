package com.example.demo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.cassandra.core.CassandraOperations;
import org.springframework.data.cassandra.core.CassandraTemplate;
import org.springframework.data.cassandra.repository.AllowFiltering;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Repository;

import com.datastax.driver.core.querybuilder.Insert;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.datastax.driver.core.querybuilder.Select;
import com.datastax.driver.core.querybuilder.Update;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class entityLayerRepository implements CassandraRepository<BussinessLayerTableDetails,Serializable>{

	private static CassandraTemplate cassandraTemplate;

	@Autowired
    public entityLayerRepository(CassandraTemplate cassandraTemplate) {
        entityLayerRepository.cassandraTemplate = cassandraTemplate;
    }
	
	@AllowFiltering
    public static List<BussinessLayerTableDetails> find(Map<?,?> map) {
        Select select = QueryBuilder.select().from("BILLING_ACTIVITY_CODE");
        Iterator<?> temp = map.entrySet().iterator();
        while(temp.hasNext())
        {
            Map.Entry<?, ?> pair = (Map.Entry<?, ?>) temp.next();
            select.where(QueryBuilder.eq((String) pair.getKey(),  pair.getValue()));
        }
        select.allowFiltering();
        return cassandraTemplate.select(select, BussinessLayerTableDetails.class);
    }
	
	@Override
	public <S extends BussinessLayerTableDetails> S insert(S entity) {
		return cassandraTemplate.insert(entity);
	}
	
	@Override
	public <S extends BussinessLayerTableDetails> S save(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<BussinessLayerTableDetails> findById(Serializable id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existsById(Serializable id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deleteById(Serializable id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(BussinessLayerTableDetails entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(Iterable<? extends BussinessLayerTableDetails> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <S extends BussinessLayerTableDetails> List<S> saveAll(Iterable<S> entites) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BussinessLayerTableDetails> findAll() {
		List<BussinessLayerTableDetails> list = new ArrayList<>();
	    ((CassandraRepository<BussinessLayerTableDetails, Serializable>) cassandraTemplate).findAll().forEach(e -> list.add(e));
	    return list;
	}

	@Override
	public List<BussinessLayerTableDetails> findAllById(Iterable<Serializable> ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Slice<BussinessLayerTableDetails> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends BussinessLayerTableDetails> List<S> insert(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	public void execute(String updateCql) {
		// TODO Auto-generated method stub
		
	}

	
	
}
