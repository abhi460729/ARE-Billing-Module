package com.example.demo;

import java.util.Collections;
import java.util.List;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.datastax.driver.core.querybuilder.Insert;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

//import com.example.entity.layer.BussinessLayerTableDetails;

@RestController
@RequestMapping("/AREBillingActivityCode")
public class BussinessLayerAPICalls extends Entity_Controller{
	
		@Autowired
		private Entity_LayerDetails service;
		
		@RequestMapping(value="/manage", method = RequestMethod.POST, produces = "application/json")
		public ResponseEntity<Object> manage(@RequestBody String data) throws JSONException{
			System.out.println("AAAAAAAAAAAAAAAAAAAA*******************"+data);
			String result=service.manage(data);
			return new ResponseEntity<>(result, HttpStatus.OK);
		}
		
		@RequestMapping(value = "/list", method = RequestMethod.POST, produces = "application/json")
		public ResponseEntity<Object> list(@RequestBody String data) throws JSONException {
		String list=service.list(data);
		return new ResponseEntity<>(list, HttpStatus.OK);
		}
		
//		
//		@RequestMapping(value="/deleteAll", method=RequestMethod.POST, produces="application/json")
//		public ResponseEntity<Object> deleteAll(){
//			service.deleteAll();
//			return new ResponseEntity<>(Collections.EMPTY_MAP,HttpStatus.OK);
//		}
//		
		@RequestMapping(value="/xmltojson", method = RequestMethod.POST, produces = "application/json")
		public ResponseEntity<Object> xmltojson(@RequestBody String data){
			String JSON=service.XMLtoJSON(data);
			return new ResponseEntity<>(JSON, HttpStatus.OK);
		}
//		
//		 
//		@RequestMapping(value = "/underscore", method = RequestMethod.POST, produces = "application/json")
//		public ResponseEntity<Object> underscore(@RequestBody String data) {
//		BussinessLayerTableDetails updatedJSON=service.underscore(data);
//		return new ResponseEntity<>(updatedJSON, HttpStatus.OK);
//		}
//		
//		@RequestMapping(value = "/select", method = RequestMethod.POST, produces = "application/json")
//		public ResponseEntity<Object> select(@RequestBody String data) throws JsonMappingException, JsonProcessingException {
//		List<BussinessLayerTableDetails> temp=service.select(data);
//		return new ResponseEntity<>(temp, HttpStatus.OK);
//		}
		    
		
}
