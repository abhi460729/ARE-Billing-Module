package com.example.demo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;

import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

@Table("billing_activity_header")

public class ARE_Billing_Activity_Header_Table {
	@SerializedName("TransactionType")
	@PrimaryKeyColumn(name = "transaction_type", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
	private String transaction_type;
	@SerializedName("AREActivityHeaderKey")
	@PrimaryKeyColumn(name = "are_activity_header_key", ordinal = 1, type = PrimaryKeyType.CLUSTERED)
	private String are_activity_header_key;
	@SerializedName("ActivityGroup")
	@PrimaryKeyColumn(name = "activity_group", ordinal = 2, type = PrimaryKeyType.CLUSTERED)
	private String activity_group;
	@SerializedName("ClientCode")
	@PrimaryKeyColumn(name = "client_code", ordinal = 3, type = PrimaryKeyType.CLUSTERED)
	private String client_code;
	@SerializedName("ShipNode")
	@PrimaryKeyColumn(name = "ship_node", ordinal = 4, type = PrimaryKeyType.CLUSTERED)
	private String ship_node;
	@SerializedName("Status")
	@Column(value="activity_status")
	private String activity_status;
	@SerializedName("StartDate")
	@JsonFormat(pattern="MM/dd/yyyy")
	@Column(value="activity_start_date")
	private Date activity_start_date;
	@SerializedName("LastDate")
	@JsonFormat(pattern="MM/dd/yyyy")
	@Column(value="last_activity_date")
	private Date last_activity_date;
	@SerializedName("InitTransmitDate")
	@JsonFormat(pattern="MM/dd/yyyy")
	@Column(value="initial_transmission_date")
	private Date initial_transmission_date;
	@SerializedName("LastTransmitDate")
	@JsonFormat(pattern="MM/dd/yyyy")
	@Column(value="last_transmission_date")
	private Date last_transmission_date;	
	@SerializedName("ActivityGroupKeyData")
	@Column(value="activity_group_key_data")
	private String activity_group_key_data;
	@SerializedName("ShipToAddr1")
	@Column(value="ship_to_address1")
	private String ship_to_address1;
	@SerializedName("ShipToAddr2")
	@Column(value="ship_to_address2")
	private String ship_to_address2;
	@SerializedName("ShipToAddr3")
	@Column(value="ship_to_address3")
	private String ship_to_address3;
	@SerializedName("ShipToAddr4")
	@Column(value="ship_to_address4")
	private String ship_to_address4;
	@SerializedName("ShipToCity")
	@Column(value="ship_to_city")
	private String ship_to_city;
	@SerializedName("ShipToState")
	@Column(value="ship_to_state")
	private String ship_to_state;
	@SerializedName("ShipToCountry")
	@Column(value="ship_to_country")
	private String ship_to_country;
	@SerializedName("ShipToZip")
	@Column(value="ship_to_zipcode")
	private String ship_to_zipcode;
	@SerializedName("CustomerRefNo")
	@Column(value="customer_reference_no")
	private String customer_reference_no;
	@SerializedName("Referencefield1")
	@Column(value="reference_field_1")
	private String reference_field_1;
	@SerializedName("Referencefield2")
	@Column(value="reference_field_2")
	private String reference_field_2;
	@SerializedName("Referencefield3")
	@Column(value="reference_field_3")
	private String reference_field_3;
	@SerializedName("OrderDate")
	@JsonFormat(pattern="dd/MM/yyyy")
	@Column(value="order_date")
	private Date order_date;
	@SerializedName("AirwayBillTo")
	@Column(value="airway_bill_to")
	private String airway_bill_to;
	@SerializedName("Createts")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss.SSS")
	@Column(value="createts")
	private Date createts;
	@SerializedName("Modifyts")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss.SSS")
	@Column(value="modifyts")
	private Date modifyts;
	@SerializedName("Createuserid")
	@Column(value="createuserid")
	private String createuserid;
	@SerializedName("Modifyuserid")
	@Column(value="modifyuserid")
	private String modifyuserid;	
	
	public ARE_Billing_Activity_Header_Table(){}
	
	public ARE_Billing_Activity_Header_Table(String transaction_type, String are_activity_header_key,
			String activity_group, String client_code, String ship_node, String activity_status,
			Date activity_start_date, Date last_activity_date, Date initial_transmission_date,
			Date last_transmission_date, String activity_group_key_data, String ship_to_address1,
			String ship_to_address2, String ship_to_address3, String ship_to_address4, String ship_to_city,
			String ship_to_state, String ship_to_country, String ship_to_zipcode, String customer_reference_no,
			String reference_field_1, String reference_field_2, String reference_field_3, Date order_date,
			String airway_bill_to, Date createts, Date modifyts, String createuserid, String modifyuserid) {

		this.transaction_type = transaction_type;
		this.are_activity_header_key = are_activity_header_key;
		this.activity_group = activity_group;
		this.client_code = client_code;
		this.ship_node = ship_node;
		this.activity_status = activity_status;
		this.activity_start_date = activity_start_date;
		this.last_activity_date = last_activity_date;
		this.initial_transmission_date = initial_transmission_date;
		this.last_transmission_date = last_transmission_date;
		this.activity_group_key_data = activity_group_key_data;
		this.ship_to_address1 = ship_to_address1;
		this.ship_to_address2 = ship_to_address2;
		this.ship_to_address3 = ship_to_address3;
		this.ship_to_address4 = ship_to_address4;
		this.ship_to_city = ship_to_city;
		this.ship_to_state = ship_to_state;
		this.ship_to_country = ship_to_country;
		this.ship_to_zipcode = ship_to_zipcode;
		this.customer_reference_no = customer_reference_no;
		this.reference_field_1 = reference_field_1;
		this.reference_field_2 = reference_field_2;
		this.reference_field_3 = reference_field_3;
		this.order_date = order_date;
		this.airway_bill_to = airway_bill_to;
		this.createts = createts;
		this.modifyts = modifyts;
		this.createuserid = createuserid;
		this.modifyuserid = modifyuserid;
	}

public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

	public String getAre_activity_header_key() {
		return are_activity_header_key;
	}

	public void setAre_activity_header_key(String are_activity_header_key) {
		this.are_activity_header_key = are_activity_header_key;
	}

	public String getActivity_group() {
		return activity_group;
	}

	public void setActivity_group(String activity_group) {
		this.activity_group = activity_group;
	}

	public String getClient_code() {
		return client_code;
	}

	public void setClient_code(String client_code) {
		this.client_code = client_code;
	}

	public String getShip_node() {
		return ship_node;
	}

	public void setShip_node(String ship_node) {
		this.ship_node = ship_node;
	}

	public String getActivity_status() {
		return activity_status;
	}

	public void setActivity_status(String activity_status) {
		this.activity_status = activity_status;
	}

	public Date getActivity_start_date() {
		return activity_start_date;
	}

	public void setActivity_start_date(Date activity_start_date) {
		this.activity_start_date = activity_start_date;
	}

	public Date getLast_activity_date() {
		return last_activity_date;
	}

	public void setLast_activity_date(Date last_activity_date) {
		this.last_activity_date = last_activity_date;
	}

	public Date getInitial_transmission_date() {
		return initial_transmission_date;
	}

	public void setInitial_transmission_date(Date initial_transmission_date) {
		this.initial_transmission_date = initial_transmission_date;
	}

	public Date getLast_transmission_date() {
		return last_transmission_date;
	}

	public void setLast_transmission_date(Date last_transmission_date) {
		this.last_transmission_date = last_transmission_date;
	}

	public String getActivity_group_key_data() {
		return activity_group_key_data;
	}

	public void setActivity_group_key_data(String activity_group_key_data) {
		this.activity_group_key_data = activity_group_key_data;
	}

	public String getShip_to_address1() {
		return ship_to_address1;
	}

	public void setShip_to_address1(String ship_to_address1) {
		this.ship_to_address1 = ship_to_address1;
	}

	public String getShip_to_address2() {
		return ship_to_address2;
	}

	public void setShip_to_address2(String ship_to_address2) {
		this.ship_to_address2 = ship_to_address2;
	}

	public String getShip_to_address3() {
		return ship_to_address3;
	}

	public void setShip_to_address3(String ship_to_address3) {
		this.ship_to_address3 = ship_to_address3;
	}

	public String getShip_to_address4() {
		return ship_to_address4;
	}

	public void setShip_to_address4(String ship_to_address4) {
		this.ship_to_address4 = ship_to_address4;
	}

	public String getShip_to_city() {
		return ship_to_city;
	}

	public void setShip_to_city(String ship_to_city) {
		this.ship_to_city = ship_to_city;
	}

	public String getShip_to_state() {
		return ship_to_state;
	}

	public void setShip_to_state(String ship_to_state) {
		this.ship_to_state = ship_to_state;
	}

	public String getShip_to_country() {
		return ship_to_country;
	}

	public void setShip_to_country(String ship_to_country) {
		this.ship_to_country = ship_to_country;
	}

	public String getShip_to_zipcode() {
		return ship_to_zipcode;
	}

	public void setShip_to_zipcode(String ship_to_zipcode) {
		this.ship_to_zipcode = ship_to_zipcode;
	}

	public String getCustomer_reference_no() {
		return customer_reference_no;
	}

	public void setCustomer_reference_no(String customer_reference_no) {
		this.customer_reference_no = customer_reference_no;
	}

	public String getReference_field_1() {
		return reference_field_1;
	}

	public void setReference_field_1(String reference_field_1) {
		this.reference_field_1 = reference_field_1;
	}

	public String getReference_field_2() {
		return reference_field_2;
	}

	public void setReference_field_2(String reference_field_2) {
		this.reference_field_2 = reference_field_2;
	}

	public String getReference_field_3() {
		return reference_field_3;
	}

	public void setReference_field_3(String reference_field_3) {
		this.reference_field_3 = reference_field_3;
	}

	public Date getOrder_date() {
		return order_date;
	}

	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}

	public String getAirway_bill_to() {
		return airway_bill_to;
	}

	public void setAirway_bill_to(String airway_bill_to) {
		this.airway_bill_to = airway_bill_to;
	}

	public Date getCreatets() {
		return createts;
	}

	public void setCreatets(Date createts) {
		this.createts = createts;
	}

	public Date getModifyts() {
		return modifyts;
	}

	public void setModifyts(Date modifyts) {
		this.modifyts = modifyts;
	}

	public String getCreateuserid() {
		return createuserid;
	}

	public void setCreateuserid(String createuserid) {
		this.createuserid = createuserid;
	}

	public String getModifyuserid() {
		return modifyuserid;
	}

	public void setModifyuserid(String modifyuserid) {
		this.modifyuserid = modifyuserid;
	}
	
}
