package com.example.demo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Service
public class Business_Layer_2_Table {
	@Autowired
	private Entity_Layer_Header_Repository cassandraTemplateHeader;
	@Autowired
	private Entity_Layer_Repository_Detail cassandraTemplateDetail;
	
	public String manage(String data) throws JSONException {
		try {
			
			//create ObjectMapper instance
			ObjectMapper objectMapper = new ObjectMapper();
			Gson gson=new Gson();
			JSONObject root=new JSONObject(data);
			JSONObject AREActivity=(JSONObject) root.get("AREActivity");
			JSONArray keys=AREActivity.names();
			
			int l=keys.length(),k=0;
			JSONObject JSONHeader=new JSONObject();
			Map<String,String> columnHeader = columnHeader();
			System.out.println(cassandraTemplateDetail.temp());
			for(int i=0;i<l;i++){
				String key=(String) keys.get(i);
				if(key.equals("AREActivityDetails")) {
					
				}
				else {
					if(columnHeader.containsKey(key))
						JSONHeader.put(columnHeader.get(key),AREActivity.get(key));
				}
			}
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSZ");
		    Date date = new Date();
		    String ts=dateFormat.format(date);
		    String Headerkey=convert();
			JSONHeader.put("are_activity_header_key",Headerkey);
			JSONHeader.put("createts",ts);
			JSONHeader.put("modifyts",ts);
			JSONHeader.put("createuserid","dc2mgr");
			JSONHeader.put("modifyuserid","dc2mgr");
			String test=JSONHeader.toString();
			System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%"+test);
			ARE_Billing_Activity_Header_Table table=objectMapper.readValue(test, ARE_Billing_Activity_Header_Table.class);
			ARE_Billing_Activity_Header_Table insert = cassandraTemplateHeader.insertHeader(table);
			JSONObject value = new JSONObject(insert);
			test=value.toString();
			System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%"+test);
			JSONObject JSONDetails=(JSONObject) AREActivity.get("AREActivityDetails");
			JSONObject det=JSONDetails.optJSONObject("AREActivityDetail");
			JSONObject JSONDetail= new JSONObject();
			JSONObject JSON= new JSONObject();
			JSONArray JSONDetailArray=new JSONArray();
			Map<String,String> columnDeatil = columnDetail();
			System.out.println("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"+det);
			if(det!=null) {
				JSONDetail=(JSONObject) JSONDetails.get("AREActivityDetail");
				JSONArray detailkeys=JSONDetail.names();
				int detl=detailkeys.length();
				for(int i=0;i<detl;i++) {
					String detailkey=(String) detailkeys.get(i);
					if(columnDeatil.containsKey(detailkey))
						JSON.put(columnDeatil.get(detailkey),JSONDetail.get(detailkey));
				}
				Instant instant = Instant.now();
				Long timeStamp = new Long(instant.toEpochMilli());
				String Detailkey=timeStamp+"";
				JSON.put("activity_header_key", Headerkey);
				JSON.put("activity_detail_key", Detailkey);
				String detailtest=JSON.toString();
				System.out.println("*************************"+detailtest.toString());
				ARE_Billing_Activity_Detail_Table detailtable=objectMapper.readValue(detailtest, ARE_Billing_Activity_Detail_Table.class);
				JSONObject detailvalue = new JSONObject(detailtable);
				System.out.println("*************************"+detailvalue.toString());
				ARE_Billing_Activity_Detail_Table detailinsert = cassandraTemplateDetail.insertDetail(detailtable);
				detailvalue = new JSONObject(detailinsert);
				System.out.println("*************************"+detailvalue.toString());
			}
			else {
				JSONDetailArray=(JSONArray)  JSONDetails.get("AREActivityDetail");
				int arrlen=JSONDetailArray.length();
				for(int i=0;i<arrlen;i++) {
					JSONObject Node=(JSONObject) JSONDetailArray.get(i);
					JSONObject detail=new JSONObject();
					JSONArray childtemp=Node.names();
					int detl=childtemp.length();
					for(int j=0;j<detl;j++){
						String childkey=(String) childtemp.get(j);
						if(columnDeatil.containsKey(childkey)) {
							detail.put(columnDeatil.get(childkey),Node.get(childkey));
						}
					}
					Instant instant = Instant.now();
					Long timeStamp = new Long(instant.toEpochMilli());
					String Detailkey=timeStamp+"";
					detail.put("activity_header_key", Headerkey);
					detail.put("activity_detail_key", Detailkey);
					String detailtest=detail.toString();
					System.out.println("*************************"+detailtest.toString());
					ARE_Billing_Activity_Detail_Table detailtable=objectMapper.readValue(detailtest, ARE_Billing_Activity_Detail_Table.class);
					JSONObject detailvalue = new JSONObject(detailtable);
					System.out.println("*************************"+detailvalue.toString());
					ARE_Billing_Activity_Detail_Table detailinsert = cassandraTemplateDetail.insert(detailtable);
					detailvalue = new JSONObject(detailinsert);
					System.out.println("*************************"+detailvalue.toString());
				}
				
			}
			return test;
		}
		catch (Exception e)
        {
            e.printStackTrace();
        }

	return null;
	}
	public String list(String data) throws JSONException {
		try {
			
			String JSON="";
			JSONArray totalList=new JSONArray();
			ObjectMapper objectMapper = new ObjectMapper();
			Gson gson=new Gson();
			JSONObject root=new JSONObject(data);
			JSONObject AREActivityCheck=(JSONObject) root.get("AREActivity");
			JSONObject AREActivity=new JSONObject();
			Map<String, String> select=new HashMap<String,String>();
			JSONObject mergeJSON=new JSONObject();
			Map<String, String> columnHeader = columnHeader();
			JSONArray keys=AREActivityCheck.names();
			
			for(int i=0;i<keys.length();i++) {
				String key = (String) keys.get(i);
				
				if(AREActivityCheck.get(key).equals("") || AREActivityCheck.get(key).equals(null) ||  AREActivityCheck.get(key).equals("Y") || AREActivityCheck.get(key).equals("BETWEEN") || AREActivityCheck.get(key).equals("XYZ-CORP") ||  AREActivityCheck.get(key).equals("list") || AREActivityCheck.get(key).equals(30)) {

				}
				else {
					System.out.println("^^^^^^^^^^^^^^^^^"+AREActivityCheck.get(key));
					AREActivity.put(key, AREActivityCheck.get(key));
				}
			}
			System.out.println(AREActivity.toString());
			List<ARE_Billing_Activity_Header_Table> list=null;
			if(AREActivity.length()==0) {
				list=cassandraTemplateHeader.selectAll();
				String headerlist = gson.toJson(list);
				JSONArray header=new JSONArray(headerlist);
				for(int j=0;j<list.size();j++)
				{
					String t=header.get(j).toString();
					JSONObject headerobj=new JSONObject(t);
					System.out.println(headerobj.toString());
					String headerkey=(String) headerobj.get("AREActivityHeaderKey");
					JSONObject selectdetail=new JSONObject();
					selectdetail.put("activity_header_key", headerkey);
					System.out.println(selectdetail.toString());
					List<ARE_Billing_Activity_Detail_Table> listdetail=cassandraTemplateDetail.find(selectdetail);
					String sample = gson.toJson(listdetail);

					JSONArray listofdetail=new JSONArray(sample);
					
					String jsondetail="";
					for(int i=0;i<listofdetail.length();i++) {
						if(i!=listofdetail.length()-1)
							jsondetail+=listofdetail.get(i).toString()+",";
						else
							jsondetail+=listofdetail.get(i).toString();
					}
					if(listofdetail.length()!=1) {
						jsondetail="{\r\n" + 
								" \"AREActivityDetails\":  {\r\n" + 
								"        \"AREActivityDetail\": [ "+ 
								jsondetail+
								" ] } \r\n" + 
								"}";
					}
					else {
						jsondetail="{\r\n" + 
								" \"AREActivityDetails\":  {\r\n" + 
								"        \"AREActivityDetail\":  "+ 
								jsondetail+
								"  } \r\n" + 
								"}";
					}
					JSONObject detail=new JSONObject(jsondetail);
					mergeJSON=mergeJSONObjects(headerobj,detail);
					if(j!=list.size()-1)
						JSON+=mergeJSON.toString()+",";
					else
						JSON+=mergeJSON.toString();
				}
				if(totalList.length()!=1) {
					JSON="{\r\n" + 
							" \"AREActivityList\":  {\r\n" + 
							"        \"AREActivity\": [ "+ 
							JSON+
							" ] } \r\n" + 
							"}";
				}
				else {
					JSON="{\r\n" + 
							" \"AREActivityList\":  {\r\n" + 
							"        \"AREActivity\":  "+ 
							JSON+
							"  } \r\n" + 
							"}";
				}
			}
			else {
				JSONArray headerkeys=AREActivity.names();
				for(int i=0;i<headerkeys.length();i++) {
					String key = (String) headerkeys.get(i);
					System.out.println(key);
					if(AREActivity.get(key).equals("") && AREActivity.get(key).equals(null))
					{
						
					}
					else {
						String column_name=columnHeader.get(key);
						String value=(String) AREActivity.get(key);
						select.put(column_name,value);
					}
						
				}
				
				list=cassandraTemplateHeader.find(select);
				String headerlist = gson.toJson(list);
				JSONArray header=new JSONArray(headerlist);
				for(int j=0;j<header.length();j++)
				{
					String t=header.get(j).toString();
					JSONObject headerobj=new JSONObject(t);
					System.out.println(headerobj.toString());
					System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%"+headerobj.toString());
					String headerkey=(String) headerobj.get("AREActivityHeaderKey");
					JSONObject selectdetail=new JSONObject();
					selectdetail.put("activity_header_key", headerkey);
					System.out.println(selectdetail.toString());
					List<ARE_Billing_Activity_Detail_Table> listdetail=cassandraTemplateDetail.find(selectdetail);
					String sample = gson.toJson(listdetail);

					JSONArray listofdetail=new JSONArray(sample);
					
					String jsondetail="";
					for(int i=0;i<listofdetail.length();i++) {		
						if(i!=listofdetail.length()-1)
							jsondetail+=listofdetail.get(i).toString()+",";
						else
							jsondetail+=listofdetail.get(i).toString();
					}
					if(listofdetail.length()!=1) {
						jsondetail="{\r\n" + 
								" \"AREActivityDetails\":  {\r\n" + 
								"        \"AREActivityDetail\": [ "+ 
								jsondetail+
								" ] } \r\n" + 
								"}";
					}
					else {
						jsondetail="{\r\n" + 
								" \"AREActivityDetails\":  {\r\n" + 
								"        \"AREActivityDetail\":  "+ 
								jsondetail+
								"  } \r\n" + 
								"}";
					}
					JSONObject detail=new JSONObject(jsondetail);
					mergeJSON=mergeJSONObjects(headerobj,detail);
					if(j!=list.size()-1)
						JSON+=mergeJSON.toString()+",";
					else
						JSON+=mergeJSON.toString();
				}
				if(totalList.length()!=1) {
					JSON="{\r\n" + 
							" \"AREActivityList\":  {\r\n" + 
							"        \"AREActivity\": [ "+ 
							JSON+
							" ] } \r\n" + 
							"}";
				}
				else {
					JSON="{\r\n" + 
							" \"AREActivityList\":  {\r\n" + 
							"        \"AREActivity\":  "+ 
							JSON+
							"  } \r\n" + 
							"}";
				}
			}
			
			System.out.println(JSON);
			
			return JSON;
		}
		catch (Exception e)
        {
            e.printStackTrace();
        }

		return null;
		
	}
		
	
	public Map<String,String> columnHeader()
	{
		Map<String, String> column=new HashMap<String, String>();
		column.put("AREActivityHeaderKey", "are_activity_header_key");
		column.put("TransactionType", "transaction_type");
		column.put("ActivityGroup", "activity_group");
		column.put("ClientCode", "client_code");
		column.put("ShipNode", "ship_node");
		column.put("Status", "activity_status");
		column.put("StartDate", "activity_start_date");
		column.put("LastDate", "last_activity_date");
		column.put("InitTransmitDate", "initial_transmission_date");
		column.put("LastTransmitDate", "last_transmission_date");
		column.put("ActivityGroupKeyData", "activity_group_key_data");
		column.put("ShipToAddr1", "ship_to_address1");
		column.put("ShipToAddr2", "ship_to_address2");
		column.put("ShipToAddr3", "ship_to_address3");
		column.put("ShipToAddr4", "ship_to_address4");
		column.put("ShipToCity", "ship_to_city");
		column.put("ShipToState", "ship_to_state");
		column.put("ShipToZip", "ship_to_zipcode");
		column.put("CustomerRefNo", "customer_reference_no");
		column.put("Referencefield1", "reference_field_1");
		column.put("Referencefield2", "reference_field_2");
		column.put("Referencefield3", "reference_field_3");
		column.put("OrderDate", "order_date");
		column.put("AirwayBillTo", "airway_bill_to");
		column.put("Createts", "createts");
		column.put("Modifyts", "modifyts");
		column.put("Createuserid", "createuserid");
		column.put("Modifyuserid", "modifyuserid");
		
		return column;
	}
	
	
	public Map<String,String> columnDetail()
	{	
		
		Map<String, String> column=new HashMap<String, String>();
		
		column.put("ActivitySubLineNo", "activity_sub_line_no");
		column.put("AREActivityHeaderKey", "activity_header_key");
		column.put("ActivityLineNo", "activity_line_no");
		column.put("ActivityCode", "activity_code");
		column.put("ActivityDate", "activity_date");
		column.put("Status", "activity_line_status");
		column.put("ServiceQty", "service_quantity");
		column.put("ActivityKeyData", "activity_key_data");
		column.put("CarrierCode", "carrier_code");
		column.put("ReferenceQty1", "reference_quantity_1");
		column.put("ReferenceQty2", "reference_quantity_2");
		column.put("ReferenceQty3", "reference_quantity_3");
		column.put("Referencefield1", "reference_field_1");
		column.put("Referencefield2", "reference_field_2");
		column.put("Referencefield3", "reference_field_3");
		column.put("ShipVia", "ship_via");
		column.put("Cost", "cost");
		column.put("Createts", "createts");
		column.put("Modifyts", "modifyts");
		column.put("Createuserid", "createuserid");
		column.put("Modifyuserid", "modifyuserid");
		
		return column;
		
	}

	public String convert() {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
	    Date date = new Date();
	    String temp=dateFormat.format(date);
	    Instant instant = Instant.now();
	    Long timeStamp = new Long(instant.toEpochMilli());
	    String ts=temp+timeStamp;
	    return ts;
		}
	
	public static JSONObject mergeJSONObjects(JSONObject json1, JSONObject json2) {
		JSONObject mergedJSON = new JSONObject();
		try {
			mergedJSON = new JSONObject(json1, JSONObject.getNames(json1));
			for (String crunchifyKey : JSONObject.getNames(json2)) {
				mergedJSON.put(crunchifyKey, json2.get(crunchifyKey));
			}
 
		} catch (JSONException e) {
			throw new RuntimeException("JSON Exception" + e);
		}
		return mergedJSON;
	}
	
}
