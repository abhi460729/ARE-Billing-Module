package com.example.demo;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datastax.driver.core.LocalDate;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;



@Service
public class Business_Layer {
	

//	@Autowired
////	private Entity_Layer_Repository cassandraTemplate;
//
//		
//		public String manage(String data) throws JSONException {
//			try {
//				
//				//create ObjectMapper instance
//				ObjectMapper objectMapper = new ObjectMapper();
//				
//				Gson gson = new Gson();
//				JSONObject root=new JSONObject(data);
//				JSONObject AREActivity=new JSONObject();
//				
//				JSONArray array=new JSONArray();
//				
//				AREActivity=(JSONObject) root.get("AREActivity");
//				String json = null;
//				JSONArray temp=AREActivity.names();
//				int l=temp.length(),k=0;
//				JSONObject JSON=new JSONObject();
//				Map<String,String> column = column();
//				
//				for(int i=0;i<l;i++){
//					String key=(String) temp.get(i);
//					
//					if(AREActivity.get(key)!=null){
//						if(key.equals("AREActivityDetails")){
//							JSONObject AREActivityDetails=(JSONObject) AREActivity.get("AREActivityDetails");
//							JSONArray AREActivityDetail=(JSONArray) AREActivityDetails.get("AREActivityDetail");
//							int noofdet=AREActivityDetail.length();
//
//							for(k=0;k<noofdet;k++) {
//								JSONObject Node=(JSONObject) AREActivityDetail.get(k);
//								JSONObject detail=new JSONObject();
//								JSONArray childtemp=Node.names();
//								int detl=childtemp.length();
//								for(int j=0;j<detl;j++){
//									String childkey=(String) childtemp.get(j);
//									if(column.containsKey(childkey)) {
//										detail.put(column.get(childkey),Node.get(childkey));
//									//JSON.put(column.get(childkey),AREActivityDetail.get(childkey));
//									}
//								}
//								json = detail.toString();
//								System.out.println("222222222222222222222222"+json);
//								array.put(k,detail);
//							}
//							
//						}
//						else {
//							if(column.containsKey(key))
//								JSON.put(column.get(key),AREActivity.get(key));
//						}
//					}
//				}
//				
//				
//				for(int i=0;i<k;i++) {
//					JSONObject deta=(JSONObject) array.get(i);
//					JSONObject insertdetail=(JSONObject) JSON;
//					JSONObject mergedJSON = mergeJSONObjects(insertdetail, deta);
//					System.out.println("\nmergedJSON: " + mergedJSON);
//					DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSZ");
//				    Date date = new Date();
//				    String ts=dateFormat.format(date);
//				    mergedJSON.put("are_activity_detail_key",ARE_Billing_Activity_Table.convert());
//				    mergedJSON.put("createts",ts);
//				    mergedJSON.put("modifyts",ts);
//				    mergedJSON.put("createuserid","dc2mgr");
//				    mergedJSON.put("modifyuserid","dc2mgr");
//					ARE_Billing_Activity_Table table=objectMapper.readValue(mergedJSON.toString(), ARE_Billing_Activity_Table.class);
//					
//					ARE_Billing_Activity_Table insert = cassandraTemplate.insert(table);
					
//					String value = gson.toJson(insert);
//					System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&"+value);
//				}
				//System.out.println("???????????????????????????????"+det[1]);
//				ARE_Billing_Activity_Table table=objectMapper.readValue(json, ARE_Billing_Activity_Table.class);
//				
//				ARE_Billing_Activity_Table insert = cassandraTemplate.insert(table);
//				
//				 
//				String value = gson.toJson(insert);
//				JSONObject sample=new JSONObject(value);
//
//				JSONObject sample1=new JSONObject();
//				sample1.accumulate("AREActivity", sample);
//				String t = sample1.toString();
//				System.out.println("VVVVVVVVVVVVVVVVvVVVVVVVVVVVVVVVVVVVVVVVVVV"+childroot);
//				//convert json file to map
//				Map<?, ?> map = objectMapper.readValue(childroot.toString(), Map.class);
//				
//				Map<String, String> column = column();
//				
//				String JSON="{\n";
//				for(Object key : map.keySet())
//				{
//						if(temp.containsKey(key)){
//							JSON+="\""+temp.get(key)+"\": \""+map.get(key)+"\",\n";
//						}
//				}
//				System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa***********************"+ JSON);
//				System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#####################"+ map.get("Code"));
//				Map<String,String> act = new HashMap<String, String>();
//				act.put("activity_code", (String) map.get("Code"));
//				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSZ");
//			    Date date = new Date();
//			    String ts=dateFormat.format(date);
//				List<ARE_Billing_Activity_Table> list=Entity_Layer_Repository.find(act);
//				 
//				int i=list.size();
//				if(i==0){
//					JSON+="\"createts\": \""+ts+"\",\n";
//					JSON+="\"modifyts\": \""+ts+"\"\n";
//				}
//				else {
//					JSON+="\"modifyts\": \""+ts+"\"\n";
//				}
//				JSON+="}";
//				
//				ARE_Billing_Activity_Table table=objectMapper.readValue(JSON, ARE_Billing_Activity_Table.class);
//				
//				ARE_Billing_Activity_Table insert = cassandraTemplate.insert(table);
//				
//				
//				 
//				String json = gson.toJson(insert);
//				
//				json="{\r\n" + 
//						" \"AREActivityCodeList\": {\r\n" + 
//						"        \"AREActivityCode\": "+ 
//						json+
//						"   }\r\n" + 
//						"}";
//
//
//				JSONObject sample=new JSONObject();
//				sample.put("status", "success");
//				JSONObject temporary=new JSONObject();
//				temporary.accumulate("AREActivity", sample);
//				return temporary.toString();
//				
//				}
//				catch (Exception e)
//		        {
//		            e.printStackTrace();
//		        }
//
//			return null;
//		}
//		
//		public List<ARE_Billing_Activity_Table> select(String data) throws JsonMappingException, JsonProcessingException {
//	           
//            //create ObjectMapper instance
//            ObjectMapper objectMapper = new ObjectMapper();
//           
//            //convert json file to map
//            Map<?, ?> map = objectMapper.readValue(data, Map.class);
//           
//            List<ARE_Billing_Activity_Table> sample=Entity_Layer_Repository.find(map);
//            return sample;
//		}
//		
		

//		public String list(String data) throws JSONException {
//			try {
//				
//				//create ObjectMapper instance
//				ObjectMapper objectMapper = new ObjectMapper();
//				
//				Gson gson = new Gson();
//				JSONObject root=new JSONObject(data);
//				JSONObject childroot=new JSONObject();
//
//				childroot=(JSONObject) root.get("AREActivity");
//				
//				Map<?, ?> newmap = objectMapper.readValue(childroot.toString(), Map.class);
//				
//				JSONArray key=childroot.names();
//			}
//			
//				for(int i=0;i<key.length();i++) {
//					if(childroot.get((String) key.get(i))!="") {
//						newmap.put(key.get(i), childroot.get((String) key.get(i)));
//					}
//				}
				
				
//				List<ARE_Billing_Activity_Table> sample=Entity_Layer_Repository.find(newmap);
				
//				String json = gson.toJson(sample);
//				System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAA"+data);
//				//convert json file to map
//				Map<?, ?> newmap = objectMapper.readValue(childroot.toString(), Map.class);
//				
//				System.out.println("1:"+newmap);
//				Map<String, String> map = new HashMap<String,String>();
//				//String select = gson.toJson(newmap);
//				for(Object key : newmap.keySet())
//				{
//					if(newmap.get(key)!="" && newmap.get(key)!=null) {
//						map.put(key.toString(),newmap.get(key).toString());
//					}
//				}
//				
//				//childroot.
//				Map<String, String> column = column();
//				
//				int l=map.size();
//				System.out.println("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"+l);
//				
//				String JSON="{\n";
//				for(Object key : temp.keySet())
//				{
//					System.out.println("rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr"+temp.get(key)+"BBBB"+map.get(key));
//						if(temp.containsKey(key) && map.get(key)!="" && map.get(key)!=null){
//							if(l>1) {
//								JSON+="\""+temp.get(key)+"\": \""+map.get(key)+"\",\n";
//								System.out.println("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"+JSON);
//							}
//							else {
//								JSON+="\""+temp.get(key)+"\": \""+map.get(key)+"\"\n";
//								System.out.println("TTTTTTTTTTTTTTTTTTTTTTTTTTTT"+JSON);
//							}
//						}
//						l--;
//				}
//				
//				JSON+="}";
//				System.out.println("dadasdwasdsadasdasdasdaddadassaada"+JSON);
//				
//				Map<?, ?> list = objectMapper.readValue(JSON, Map.class);
//				
//				System.out.println("dadasdwasdsadasdasdasdaddadassaada"+JSON);
//				
//				List<ARE_Billing_Activity_Table> sample=Entity_Layer_Repository.find(list);
//				
//				System.out.println("VVVVVVVVVVVVVVVVvVVVVVVVVVVVVVVVVVVVVVVVVVV"+childroot);
//				 
//				String json = gson.toJson(sample);
//				
//				json="{\r\n" + 
//						" \"AREActivityCodeList\": {\r\n" + 
//						"        \"AREActivityCode\": "+ 
//						json+
//						"   }\r\n" + 
//						"}";
//
//				
//				return json;
//				
//				}
//				catch (Exception e)
//		        {
//		            e.printStackTrace();
//		        }
//			return null;
//		}
		
		public Map<String,String> column()
		{
			Map<String, String> column=new HashMap<String, String>();
			column.put("AREActivityDetailKey", "are_activity_detail_key");
			column.put("TransactionType", "transaction_type");
			column.put("ActivityGroup", "activity_group");
			column.put("ClientCode", "client_code");
			column.put("ShipNode", "ship_node");
			column.put("Status", "activity_status");
			column.put("StartDate", "activity_start_date");
			column.put("LastDate", "last_activity_date");
			column.put("InitTransmitDate", "initial_transmission_date");
			column.put("LastTransmitDate", "last_transmission_date");
			column.put("ShipToAddr1", "ship_to_address1");
			column.put("ShipToAddr2", "ship_to_address2");
			column.put("ShipToAddr3", "ship_to_address3");
			column.put("ShipToAddr4", "ship_to_address4");
			column.put("ShipToCity", "ship_to_city");
			column.put("ShipToState", "ship_to_state");
			column.put("ShipToZip", "ship_to_zipcode");
			column.put("CustomerRefNo", "customer_reference_no");
			column.put("OrderDate", "order_date");
			column.put("AirwayBillTo", "airway_bill_to");
			column.put("ActivitySubLineNo", "activity_sub_line_no");
			column.put("ActivityLineNo", "activity_line_no");
			column.put("ActivityCode", "activity_code");
			column.put("ActivityDate", "activity_date");
			column.put("ServiceQty", "service_quantity");
			column.put("ActivityKeyData", "activity_key_data");
			column.put("CarrierCode", "carrier_code");
			column.put("ShipVia", "ship_via");
			column.put("Cost", "cost");
			column.put("Createts", "createts");
			column.put("Modifyts", "modifyts");
			column.put("Createuserid", "createuserid");
			column.put("Modifyuserid", "modifyuserid");
			
			
			
			return column;
			
		}
		
		public static JSONObject mergeJSONObjects(JSONObject json1, JSONObject json2) {
			JSONObject mergedJSON = new JSONObject();
			try {
				mergedJSON = new JSONObject(json1, JSONObject.getNames(json1));
				for (String crunchifyKey : JSONObject.getNames(json2)) {
					mergedJSON.put(crunchifyKey, json2.get(crunchifyKey));
				}
	 
			} catch (JSONException e) {
				throw new RuntimeException("JSON Exception" + e);
			}
			return mergedJSON;
		}
		
//			
//		public String XMLtoJSON(String data) {
//			try {
//				
//				
//				// Create a new XmlMapper to read XML tags
//	            XmlMapper xmlMapper = new XmlMapper();
//	            
//	            //Reading the XML
//	            JsonNode jsonNode = xmlMapper.readTree(data.getBytes());
//	            
//	            //Create a new ObjectMapper
//	            ObjectMapper objectMapper = new ObjectMapper();
//	            
//	            //Get JSON as a string
//	            String value = objectMapper.writeValueAsString(jsonNode);
//	            
//	            return value;
//				
//			}
//			catch (JsonParseException e)
//	        {
//	            e.printStackTrace();
//	        } catch (JsonMappingException e)
//	        {
//	            e.printStackTrace();
//	        } catch (IOException e)
//	        {
//	            e.printStackTrace();
//	        }
//			return data;
//		}
//		
		
}
