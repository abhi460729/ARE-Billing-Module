package com.example.demo;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.cassandra.core.CassandraTemplate;
import org.springframework.data.cassandra.repository.AllowFiltering;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Repository;

import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.datastax.driver.core.querybuilder.Select;

@Repository
public class Entity_Layer_Repository_Detail implements CassandraRepository<ARE_Billing_Activity_Detail_Table,Serializable>{

	private static CassandraTemplate cassandraDetailTemplate;

	@Autowired
    public Entity_Layer_Repository_Detail(CassandraTemplate cassandraTemplate) {
		Entity_Layer_Repository_Detail.cassandraDetailTemplate = cassandraTemplate;
    }
	
	@AllowFiltering
    public List<ARE_Billing_Activity_Detail_Table> find(JSONObject list) throws JSONException {
    	System.out.println(list.toString());
    	Select select = QueryBuilder.select().from("BILLING_ACTIVITY_DETAIL");
        JSONArray keys=list.names();
		for(int i=0;i<keys.length();i++) {
			String key = (String) keys.get(i);
			select.where(QueryBuilder.eq( key, list.get(key)));
		}
        select.allowFiltering();
        System.out.println(select.toString());
        return cassandraDetailTemplate.select(select, ARE_Billing_Activity_Detail_Table.class);
    }
    
	public ARE_Billing_Activity_Detail_Table insertDetail(ARE_Billing_Activity_Detail_Table detailtable) {
		if(detailtable!=null) {
		System.out.println(detailtable.toString());
		return cassandraDetailTemplate.insert(detailtable);
		}
		return detailtable;
	}
    
	
	public String temp() {
		return "hi";
	}
	@Override
	public <S extends ARE_Billing_Activity_Detail_Table> S insert(S entity) {
		return cassandraDetailTemplate.insert(entity);
	}
	
	@Override
	public <S extends ARE_Billing_Activity_Detail_Table> S save(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<ARE_Billing_Activity_Detail_Table> findById(Serializable id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existsById(Serializable id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deleteById(Serializable id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(ARE_Billing_Activity_Detail_Table entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(Iterable<? extends ARE_Billing_Activity_Detail_Table> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <S extends ARE_Billing_Activity_Detail_Table> List<S> saveAll(Iterable<S> entites) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ARE_Billing_Activity_Detail_Table> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ARE_Billing_Activity_Detail_Table> findAllById(Iterable<Serializable> ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Slice<ARE_Billing_Activity_Detail_Table> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends ARE_Billing_Activity_Detail_Table> List<S> insert(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	public void execute(String updateCql) {
		// TODO Auto-generated method stub
		
	}

	
	
}
