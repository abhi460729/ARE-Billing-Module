package com.example.demo;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.cassandra.core.CassandraTemplate;
import org.springframework.data.cassandra.repository.AllowFiltering;
import org.springframework.data.cassandra.repository.CassandraRepository;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Repository;


import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.datastax.driver.core.querybuilder.Select;


@Repository
class Entity_Layer_Header_Repository implements CassandraRepository<ARE_Billing_Activity_Header_Table,Serializable>{

	
	@Autowired
	private static CassandraTemplate cassandraTemplate;
    public Entity_Layer_Header_Repository(CassandraTemplate cassandraTemplate) {
		Entity_Layer_Header_Repository.cassandraTemplate = cassandraTemplate;
    }
	
    @AllowFiltering
    public List<ARE_Billing_Activity_Header_Table> find(Map<?,?> map) {
        Select select = QueryBuilder.select().from("BILLING_ACTIVITY_HEADER");
        Iterator<?> temp = map.entrySet().iterator();
        while(temp.hasNext())
        {
            Map.Entry<?, ?> pair = (Map.Entry<?, ?>) temp.next();
            select.where(QueryBuilder.eq((String) pair.getKey(), pair.getValue()));
        }
        select.allowFiltering();
        return cassandraTemplate.select(select, ARE_Billing_Activity_Header_Table.class);
    }
	
	public <S extends ARE_Billing_Activity_Header_Table> ARE_Billing_Activity_Header_Table insertHeader(ARE_Billing_Activity_Header_Table table) {
		System.out.println(table.toString());
		return cassandraTemplate.insert(table);
	}
	
	@Override
	public <S extends ARE_Billing_Activity_Header_Table> S save(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<ARE_Billing_Activity_Header_Table> findById(Serializable id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existsById(Serializable id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deleteById(Serializable id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(ARE_Billing_Activity_Header_Table entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(Iterable<? extends ARE_Billing_Activity_Header_Table> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <S extends ARE_Billing_Activity_Header_Table> List<S> saveAll(Iterable<S> entites) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ARE_Billing_Activity_Header_Table> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ARE_Billing_Activity_Header_Table> findAllById(Iterable<Serializable> ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Slice<ARE_Billing_Activity_Header_Table> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends ARE_Billing_Activity_Header_Table> List<S> insert(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	public void execute(String updateCql) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <S extends ARE_Billing_Activity_Header_Table> S insert(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ARE_Billing_Activity_Header_Table> selectAll() {
		 Select select = QueryBuilder.select().from("BILLING_ACTIVITY_HEADER");
		 return cassandraTemplate.select(select, ARE_Billing_Activity_Header_Table.class);
	}

	
	
}
