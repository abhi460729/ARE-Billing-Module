package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ARE_Billing_Module_Application {

	public static void main(String[] args) {
		SpringApplication.run(ARE_Billing_Module_Application.class, args);
	}

}
