package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.cassandra.config.AbstractCassandraConfiguration;
import org.springframework.data.cassandra.config.CassandraClusterFactoryBean;
import org.springframework.data.cassandra.core.mapping.CassandraMappingContext;
@Configuration
public class Cassandra_Config extends AbstractCassandraConfiguration{
	
	private String CASSANDRA_CONTACTPOINT;

	 
	 @Value("${spring.data.cassandra.keyspace-name}")
	 private String CASSANDRA_KEYSPACE;
	 
	 @Value("${spring.data.cassandra.username}")
	 private String CASSANDRA_USERNAME;
	 
	 @Value("${spring.data.cassandra.port}")
	  private int port;
	 
	 @Value("${spring.data.cassandra.password}")
	 private String CASSANDRA_PASSWORD;
	 
	 @Override
	 protected String getKeyspaceName() {
		 return CASSANDRA_KEYSPACE;
		 }
	 
	 @Override
	 protected boolean getMetricsEnabled() { return false; }
	 
	 @Override
	 public CassandraClusterFactoryBean cluster() {
		 super.cluster();
		 CassandraClusterFactoryBean cluster = new CassandraClusterFactoryBean();
		 cluster.setJmxReportingEnabled(false);
		 cluster.setContactPoints(getContactPoints());
		 cluster.setPort(getPort());
		 cluster.setUsername("cassandra");
		 cluster.setPassword("cassandra");
		 return cluster;
	 }
	 
	 @Bean
	 public CassandraMappingContext cassandraMapping() throws ClassNotFoundException {
	 return new CassandraMappingContext();
	 }
	 
	 Cassandra_Config(
		      @Value("${spring.data.cassandra.keyspace-name}") String keyspace,
		      @Value("${spring.data.cassandra.contact-points}") String hosts,
		      @Value("${spring.data.cassandra.port}") int port,
		      @Value("${spring.data.cassandra.username}") String username,
		      @Value("${spring.data.cassandra.password}") String password) {
		    this.CASSANDRA_KEYSPACE = keyspace;
		    this.CASSANDRA_CONTACTPOINT = hosts;
		    this.port = port;
		    this.CASSANDRA_USERNAME = username;
		    this.CASSANDRA_PASSWORD = password;
		  }
	 
	  @Override
	  protected String getContactPoints() {
	    return CASSANDRA_CONTACTPOINT;
	  }
	  
	  

}
