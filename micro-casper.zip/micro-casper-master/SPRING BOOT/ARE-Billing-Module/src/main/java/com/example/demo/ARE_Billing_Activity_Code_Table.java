package com.example.demo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;

import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.google.gson.annotations.SerializedName;

@Table("billing_activity_code")

public class ARE_Billing_Activity_Code_Table {
	@SerializedName("Code")
	@PrimaryKeyColumn(name = "activity_code", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
	private String activity_code;
	@SerializedName("UOM")
	@Column(value="unit_of_measure")
	private String unit_of_measure;
	@SerializedName("TransactionType")
	@Column(value="transaction_type")
	private String transaction_type;
	@SerializedName("Currency")
	@Column(value="currency")
	private String currency;
	@SerializedName("Cost")
	@Column(value="cost")
	private int cost;
	@SerializedName("AREActivityCodeKey")
	@Column(value="are_activity_key")
	private String are_activity_key;
	@SerializedName("TrackType")
	@Column(value="activity_track_type")
	private String activity_track_type;
	@SerializedName("Name")
	@Column(value="activity_name")
	private String activity_name;
	@SerializedName("ActivityGroup")
	@Column(value="activity_group")
	private String activity_group;
	@SerializedName("Createts")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss.SSS")
	@Column(value="createts")
	private Date createts;
	@SerializedName("Modifyts")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss.SSS")
	@Column(value="modifyts")
	private Date modifyts;
	@SerializedName("Createuserid")
	@Column(value="createuserid")
	private String createuserid;
	@SerializedName("Modifyuserid")
	@Column(value="modifyuserid")
	private String modifyuserid;	
	
	public ARE_Billing_Activity_Code_Table(){}
	
	public ARE_Billing_Activity_Code_Table(String activity_code, String unit_of_measure, String transaction_type,
			String currency, int cost, String are_activity_key, String activity_track_type, String activity_name,
			String activity_group, String createuserid, String modifyuserid) {
		this.activity_code = activity_code;
		this.unit_of_measure = unit_of_measure;
		this.transaction_type = transaction_type;
		this.currency = currency;
		this.cost = cost;
		this.are_activity_key = are_activity_key;
		this.activity_track_type = activity_track_type;
		this.activity_name = activity_name;
		this.activity_group = activity_group;
		this.createuserid = createuserid;
		this.modifyuserid = modifyuserid;
	}
	
	public String convert() {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
	    Date date = new Date();
	    String temp=dateFormat.format(date);
	    Instant instant = Instant.now();
	    Long timeStamp = new Long(instant.toEpochMilli());
	    String ts=temp+timeStamp;
	    return ts;
		}
	
	public String getActivity_code() {
		return activity_code;
	}
	public void setActivity_code(String activity_code) {
		this.activity_code = activity_code;
	}
	public String getUnit_of_measure() {
		return unit_of_measure;
	}
	public void setUnit_of_measure(String unit_of_measure) {
		this.unit_of_measure = unit_of_measure;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public String getAre_activity_key() {
		return are_activity_key;
	}
	public void setAre_activity_key(String are_activity_key) {
		this.are_activity_key = are_activity_key;
	}
	public String getActivity_track_type() {
		return activity_track_type;
	}
	public void setActivity_track_type(String activity_track_type) {
		this.activity_track_type = activity_track_type;
	}
	public String getActivity_name() {
		return activity_name;
	}
	public void setActivity_name(String activity_name) {
		this.activity_name = activity_name;
	}
	public String getActivity_group() {
		return activity_group;
	}
	public void setActivity_group(String activity_group) {
		this.activity_group = activity_group;
	}
	public Date getCreatets() {
		return createts;
	}

	public void setCreatets(Date createts) {
		this.createts = createts;
	}

	public Date getModifyts() {
		return modifyts;
	}

	public void setModifyts(Date modifyts) {
		this.modifyts = modifyts;
	}

	public String getCreateuserid() {
		return createuserid;
	}

	public void setCreateuserid(String createuserid) {
		this.createuserid = createuserid;
	}

	public String getModifyuserid() {
		return modifyuserid;
	}

	public void setModifyuserid(String modifyuserid) {
		this.modifyuserid = modifyuserid;
	}

		
}