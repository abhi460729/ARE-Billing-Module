package com.example.demo;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Service
class Business_Layer_ARE_Activity {
	@Autowired
	private Entity_Layer_Header_Repository cassandraTemplateHeader;
	@Autowired
	private Entity_Layer_Repository_Detail cassandraTemplateDetail;
	
	public String manage(String data) throws JSONException {
		try {
			
			//create ObjectMapper instance
			ObjectMapper objectMapper = new ObjectMapper();
			Gson gson=new Gson();
			JSONObject root=new JSONObject(data);
			JSONObject AREActivity=(JSONObject) root.get("AREActivity");
			JSONArray keys=AREActivity.names();
			
			int l=keys.length(),k=0;
			JSONObject JSONHeader=new JSONObject();
			Map<String,String> columnHeader = columnHeader();
			System.out.println(cassandraTemplateDetail.temp());
			for(int i=0;i<l;i++){
				String key=(String) keys.get(i);
				if(key.equals("AREActivityDetails")) {
					
				}
				else {
					if(columnHeader.containsKey(key))
						JSONHeader.put(columnHeader.get(key),AREActivity.get(key));
				}
			}
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSZ");
		    Date date = new Date();
		    String ts=dateFormat.format(date);
		    String Headerkey=convert();
			JSONHeader.put("are_activity_header_key",Headerkey);
			JSONHeader.put("createts",ts);
			JSONHeader.put("modifyts",ts);
			JSONHeader.put("createuserid","dc1mgr");
			JSONHeader.put("modifyuserid","dc1mgr");
			String test=JSONHeader.toString();
			System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%"+test);
			ARE_Billing_Activity_Header_Table table=objectMapper.readValue(test, ARE_Billing_Activity_Header_Table.class);
			ARE_Billing_Activity_Header_Table insert = cassandraTemplateHeader.insertHeader(table);
			JSONObject value = new JSONObject(insert);
			test=value.toString();
			System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%"+test);
			JSONObject JSONDetails=(JSONObject) AREActivity.get("AREActivityDetails");
			JSONObject det=JSONDetails.optJSONObject("AREActivityDetail");
			JSONObject JSONDetail= new JSONObject();
			JSONObject JSON= new JSONObject();
			JSONArray JSONDetailArray=new JSONArray();
			Map<String,String> columnDeatil = columnDetail();
			System.out.println("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"+det);
			if(det!=null) {
				JSONDetail=(JSONObject) JSONDetails.get("AREActivityDetail");
				JSONArray detailkeys=JSONDetail.names();
				int detl=detailkeys.length();
				for(int i=0;i<detl;i++) {
					String detailkey=(String) detailkeys.get(i);
					if(columnDeatil.containsKey(detailkey))
						if(columnDeatil.get(detailkey).equals("reference_quantity_1")) {
							String s=(String) JSONDetail.get(detailkey);
							double d=Double.parseDouble(s);
							int valuedetail=(int) d;
							JSON.put(columnDeatil.get(detailkey),valuedetail);
						}
						else
						JSON.put(columnDeatil.get(detailkey),JSONDetail.get(detailkey));
				}
				Instant instant = Instant.now();
				Long timeStamp = new Long(instant.toEpochMilli());
				String Detailkey=timeStamp+"";
				JSON.put("activity_header_key", Headerkey);
				JSON.put("activity_detail_key", Detailkey);
				String detailtest=JSON.toString();
				System.out.println("*************************"+detailtest.toString());
				ARE_Billing_Activity_Detail_Table detailtable=objectMapper.readValue(detailtest, ARE_Billing_Activity_Detail_Table.class);
				JSONObject detailvalue = new JSONObject(detailtable);
				System.out.println("*************************"+detailvalue.toString());
				ARE_Billing_Activity_Detail_Table detailinsert = cassandraTemplateDetail.insertDetail(detailtable);
				detailvalue = new JSONObject(detailinsert);
				System.out.println("*************************"+detailvalue.toString());
			}
			else {
				JSONDetailArray=(JSONArray)  JSONDetails.get("AREActivityDetail");
				int arrlen=JSONDetailArray.length();
				for(int i=0;i<arrlen;i++) {
					JSONObject Node=(JSONObject) JSONDetailArray.get(i);
					System.out.println(Node.toString());
					JSONObject detail=new JSONObject();
					JSONArray childtemp=Node.names();
					int detl=childtemp.length();
					for(int j=0;j<detl;j++){
						String childkey=(String) childtemp.get(j);
						if(columnDeatil.containsKey(childkey)) {
							if(columnDeatil.get(childkey)=="reference_quantity_1") {
								System.out.println("1111111111111111111"+(String) Node.get(childkey));
								String s=(String) Node.get(childkey);
								double d=Double.parseDouble(s);
								int valuedetail=(int) d;
								JSON.put(columnDeatil.get(childkey),valuedetail);
							}
							else {
							detail.put(columnDeatil.get(childkey),Node.get(childkey));
							}
						}
					}
					System.out.println("222222222222222222222222222222222222"+Node.toString());
					Instant instant = Instant.now();
					Long timeStamp = new Long(instant.toEpochMilli());
					String Detailkey=timeStamp+"";
					detail.put("activity_header_key", Headerkey);
					detail.put("activity_detail_key", Detailkey);
					String detailtest=detail.toString();
					System.out.println("*************************"+detailtest.toString());
					ARE_Billing_Activity_Detail_Table detailtable=objectMapper.readValue(detailtest, ARE_Billing_Activity_Detail_Table.class);
					JSONObject detailvalue = new JSONObject(detailtable);
					System.out.println("*************************"+detailvalue.toString());
					ARE_Billing_Activity_Detail_Table detailinsert = cassandraTemplateDetail.insert(detailtable);
					detailvalue = new JSONObject(detailinsert);
					System.out.println("*************************"+detailvalue.toString());
				}
				
			}
			return test;
		}
		catch (Exception e)
        {
            e.printStackTrace();
        }

	return null;
	}
	public String list(String data) throws JSONException {
		try {
			
			String JSON="";
			JSONArray totalList=new JSONArray();
			ObjectMapper objectMapper = new ObjectMapper();
			Gson gson=new Gson();
			JSONObject root=new JSONObject(data);
			JSONObject AREActivityCheck=(JSONObject) root.get("AREActivity");
			JSONObject AREActivity=new JSONObject();
			Map<String, String> select=new HashMap<String,String>();
			JSONObject mergeJSON=new JSONObject();
			Map<String, String> columnHeader = columnHeader();
			JSONArray keys=AREActivityCheck.names();
			
			for(int i=0;i<keys.length();i++) {
				String key = (String) keys.get(i);
				
				if(AREActivityCheck.get(key).equals("") || AREActivityCheck.get(key).equals(null) ||  AREActivityCheck.get(key).equals("Y") || AREActivityCheck.get(key).equals("BETWEEN") || AREActivityCheck.get(key).equals("XYZ-CORP") ||  AREActivityCheck.get(key).equals("list") || AREActivityCheck.get(key).equals(30) || AREActivityCheck.get(key).equals("EQ")) {

				}
				else if(columnHeader.containsKey(key)){
					System.out.println("^^^^^^^^^^^^^^^^^"+AREActivityCheck.get(key));
					AREActivity.put(key, AREActivityCheck.get(key));
				}
			}
			System.out.println(AREActivity.toString());
			List<ARE_Billing_Activity_Header_Table> list=null;
			if(AREActivity.length()==0) {
				list=cassandraTemplateHeader.selectAll();
				String headerlist = gson.toJson(list);
				JSONArray header=new JSONArray(headerlist);
				for(int j=0;j<list.size();j++)
				{
					String t=header.get(j).toString();
					JSONObject headerobj=new JSONObject(t);
					headerobj.remove("LastDate");
					headerobj.remove("Modifyts");
					headerobj.remove("LastTransmitDate");
					headerobj.remove("Createts");
					headerobj.remove("InitTransmitDate");
					System.out.println(headerobj.toString());
					String headerkey=(String) headerobj.get("AREActivityHeaderKey");
					JSONObject selectdetail=new JSONObject();
					selectdetail.put("activity_header_key", headerkey);
					System.out.println(selectdetail.toString());
					List<ARE_Billing_Activity_Detail_Table> listdetail=cassandraTemplateDetail.find(selectdetail);
					String sample = gson.toJson(listdetail);

					JSONArray listofdetail=new JSONArray(sample);
					
					String jsondetail="";
					for(int i=0;i<listofdetail.length();i++) {
						if(i!=listofdetail.length()-1)
							jsondetail+=listofdetail.get(i).toString()+",";
						else
							jsondetail+=listofdetail.get(i).toString();
					}
					if(listofdetail.length()!=1) {
						jsondetail="{\r\n" + 
								" \"AREActivityDetails\":  {\r\n" + 
								"        \"AREActivityDetail\": [ "+ 
								jsondetail+
								" ] } \r\n" + 
								"}";
					}
					else {
						jsondetail="{\r\n" + 
								" \"AREActivityDetails\":  {\r\n" + 
								"        \"AREActivityDetail\":  "+ 
								jsondetail+
								"  } \r\n" + 
								"}";
					}
					JSONObject detail=new JSONObject(jsondetail);
					mergeJSON=mergeJSONObjects(headerobj,detail);
					if(j!=list.size()-1)
						JSON+=mergeJSON.toString()+",";
					else
						JSON+=mergeJSON.toString();
				}
				if(totalList.length()!=1) {
					JSON="{\r\n" + 
							" \"AREActivityList\":  {\r\n" + 
							"        \"AREActivity\": [ "+ 
							JSON+
							" ] } \r\n" + 
							"}";
				}
				else {
					JSON="{\r\n" + 
							" \"AREActivityList\":  {\r\n" + 
							"        \"AREActivity\":  "+ 
							JSON+
							"  } \r\n" + 
							"}";
				}
			}
			else {
				JSONArray headerkeys=AREActivity.names();
				for(int i=0;i<headerkeys.length();i++) {
					String key = (String) headerkeys.get(i);
					System.out.println(key);
					if(AREActivity.get(key).equals("") && AREActivity.get(key).equals(null))
					{
						
					}
					else if(columnHeader.containsKey(key)){
						String column_name=columnHeader.get(key);
						String value=(String) AREActivity.get(key);
						select.put(column_name,value);
					}
						
				}
				
				list=cassandraTemplateHeader.find(select);
				String headerlist = gson.toJson(list);
				JSONArray header=new JSONArray(headerlist);
				for(int j=0;j<header.length();j++)
				{
					String t=header.get(j).toString();
					JSONObject headerobj=new JSONObject(t);
					headerobj.remove("LastDate");
					headerobj.remove("Modifyts");
					headerobj.remove("LastTransmitDate");
					headerobj.remove("Createts");
					headerobj.remove("InitTransmitDate");
					System.out.println(headerobj.toString());
					System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%"+headerobj.toString());
					String headerkey=(String) headerobj.get("AREActivityHeaderKey");
					JSONObject selectdetail=new JSONObject();
					selectdetail.put("activity_header_key", headerkey);
					System.out.println(selectdetail.toString());
					List<ARE_Billing_Activity_Detail_Table> listdetail=cassandraTemplateDetail.find(selectdetail);
					String sample = gson.toJson(listdetail);

					JSONArray listofdetail=new JSONArray(sample);
					
					String jsondetail="";
					for(int i=0;i<listofdetail.length();i++) {		
						if(i!=listofdetail.length()-1)
							jsondetail+=listofdetail.get(i).toString()+",";
						else
							jsondetail+=listofdetail.get(i).toString();
					}
					if(listofdetail.length()!=1) {
						jsondetail="{\r\n" + 
								" \"AREActivityDetails\":  {\r\n" + 
								"        \"AREActivityDetail\": [ "+ 
								jsondetail+
								" ] } \r\n" + 
								"}";
					}
					else {
						jsondetail="{\r\n" + 
								" \"AREActivityDetails\":  {\r\n" + 
								"        \"AREActivityDetail\":  "+ 
								jsondetail+
								"  } \r\n" + 
								"}";
					}
					JSONObject detail=new JSONObject(jsondetail);
					mergeJSON=mergeJSONObjects(headerobj,detail);
					if(j!=list.size()-1)
						JSON+=mergeJSON.toString()+",";
					else
						JSON+=mergeJSON.toString();
				}
				if(totalList.length()!=1) {
					JSON="{\r\n" + 
							" \"AREActivityList\":  {\r\n" + 
							"        \"AREActivity\": [ "+ 
							JSON+
							" ] } \r\n" + 
							"}";
				}
				else {
					JSON="{\r\n" + 
							" \"AREActivityList\":  {\r\n" + 
							"        \"AREActivity\":  "+ 
							JSON+
							"  } \r\n" + 
							"}";
				}
			}
			
			System.out.println(JSON);
			
			return JSON;
		}
		catch (Exception e)
        {
            e.printStackTrace();
        }

		return null;
		
	}	
	
	public Map<String,String> columnHeader()
	{
		Map<String, String> column=new HashMap<String, String>();
		column.put("AREActivityHeaderKey", "are_activity_header_key");
		column.put("TransactionType", "transaction_type");
		column.put("ActivityGroup", "activity_group");
		column.put("ClientCode", "client_code");
		column.put("ShipNode", "ship_node");
		column.put("Status", "activity_status");
		column.put("StartDate", "activity_start_date");
		column.put("LastDate", "last_activity_date");
		column.put("InitTransmitDate", "initial_transmission_date");
		column.put("LastTransmitDate", "last_transmission_date");
		column.put("ActivityGroupKeyData", "activity_group_key_data");
		column.put("ShipToAddr1", "ship_to_address1");
		column.put("ShipToAddr2", "ship_to_address2");
		column.put("ShipToAddr3", "ship_to_address3");
		column.put("ShipToAddr4", "ship_to_address4");
		column.put("ShipToCity", "ship_to_city");
		column.put("ShipToState", "ship_to_state");
		column.put("ShipToZip", "ship_to_zipcode");
		column.put("CustomerRefNo", "customer_reference_no");
		column.put("Referencefield1", "reference_field_1");
		column.put("Referencefield2", "reference_field_2");
		column.put("Referencefield3", "reference_field_3");
		column.put("OrderDate", "order_date");
		column.put("AirwayBillTo", "airway_bill_to");
		column.put("Createts", "createts");
		column.put("Modifyts", "modifyts");
		column.put("Createuserid", "createuserid");
		column.put("Modifyuserid", "modifyuserid");
		
		return column;
	}
	
	
	public Map<String,String> columnDetail()
	{	
		
		Map<String, String> column=new HashMap<String, String>();
		
		column.put("ActivitySubLineNo", "activity_sub_line_no");
		column.put("AREActivityHeaderKey", "activity_header_key");
		column.put("ActivityLineNo", "activity_line_no");
		column.put("ActivityCode", "activity_code");
		column.put("ActivityDate", "activity_date");
		column.put("Status", "activity_line_status");
		column.put("ServiceQty", "service_quantity");
		column.put("ActivityKeyData", "activity_key_data");
		column.put("CarrierCode", "carrier_code");
		column.put("ReferenceQty1", "reference_quantity_1");
		column.put("ReferenceQty2", "reference_quantity_2");
		column.put("ReferenceQty3", "reference_quantity_3");
		column.put("Referencefield1", "reference_field_1");
		column.put("Referencefield2", "reference_field_2");
		column.put("Referencefield3", "reference_field_3");
		column.put("ShipVia", "ship_via");
		column.put("Cost", "cost");
		column.put("Createts", "createts");
		column.put("Modifyts", "modifyts");
		column.put("Createuserid", "createuserid");
		column.put("Modifyuserid", "modifyuserid");
		
		return column;
		
	}

	public String convert() {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
	    Date date = new Date();
	    String temp=dateFormat.format(date);
	    Instant instant = Instant.now();
	    Long timeStamp = new Long(instant.toEpochMilli());
	    String ts=temp+timeStamp;
	    return ts;
		}
	
	public static JSONObject mergeJSONObjects(JSONObject json1, JSONObject json2) {
		JSONObject mergedJSON = new JSONObject();
		try {
			mergedJSON = new JSONObject(json1, JSONObject.getNames(json1));
			for (String crunchifyKey : JSONObject.getNames(json2)) {
				mergedJSON.put(crunchifyKey, json2.get(crunchifyKey));
			}
 
		} catch (JSONException e) {
			throw new RuntimeException("JSON Exception" + e);
		}
		return mergedJSON;
	}
	
}




@Service
class Business_Layer_ARE_Activity_Code {
	@Autowired
	private Entity_Layer_Activity_Code_Repository cassandraTemplate;

		public String manage(String data) throws JSONException {
			try {
				
				//create ObjectMapper instance
				ObjectMapper objectMapper = new ObjectMapper();
				
				Gson gson=new Gson();
				
				JSONObject root=new JSONObject(data);
				JSONObject AREActivityCode=(JSONObject) root.get("AREActivityCode");
				JSONArray keys=AREActivityCode.names();
				
				//Map<?, ?> map = objectMapper.readValue(AREActivityCode.toString(), Map.class);
				
				Map<String, String> columnCode = columnCode();
				int l=keys.length(),k=0;
				JSONObject JSON=new JSONObject();
				for(int i=0;i<l;i++){
					String key=(String) keys.get(i);
					if(columnCode.containsKey(key))
						if(columnCode.get(key).equals("cost")) {
							String s=(String) AREActivityCode.get(key);
							double d=Double.parseDouble(s);
							int value=(int) d;
							JSON.put(columnCode.get(key),value);
						}
						else
						JSON.put(columnCode.get(key),AREActivityCode.get(key));
				}
				
				JSONObject select=new JSONObject();
				select.put("activity_code", AREActivityCode.get("Code").toString());
				
				List<ARE_Billing_Activity_Code_Table> list=Entity_Layer_Activity_Code_Repository.find(select);
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSZ");
			    Date date = new Date();
			    String ts=dateFormat.format(date);
				JSON.put("createuserid", "dc1mgr");
				JSON.put("modifyuserid", "dc1mgr");
				int i=list.size();
				if(i==0){
					JSON.put("createts", ts);
					JSON.put("modifyts", ts);
					JSON.put("are_activity_key", convert());
				}
				else {
					JSON.put("modifyts", ts);
				}
				
				String test=JSON.toString();
				
				ARE_Billing_Activity_Code_Table table=objectMapper.readValue(test, ARE_Billing_Activity_Code_Table.class);
				
				ARE_Billing_Activity_Code_Table insert = cassandraTemplate.insert(table);
				

				String codelisttest = gson.toJson(insert);
				JSONObject ARE_Activity_Code_Insert= new JSONObject(codelisttest);
				JSONObject codelist=new JSONObject();
				codelist=codelist.put("AREActivityCode", ARE_Activity_Code_Insert);
				JSONObject ARE_Activity_Code_List=new JSONObject();
				ARE_Activity_Code_List=ARE_Activity_Code_List.put("AREActivityCodeList", codelist);
				
				return ARE_Activity_Code_List.toString();
				
				}
				catch (JsonParseException e)
		        {
		            e.printStackTrace();
		        } catch (JsonMappingException e)
		        {
		            e.printStackTrace();
		        } catch (IOException e)
		        {
		            e.printStackTrace();
		        }
			return null;
		}
//		
//		public List<ARE_Activity_Code_Table> select(String data) throws JsonMappingException, JsonProcessingException {
//	           
//            //create ObjectMapper instance
//            ObjectMapper objectMapper = new ObjectMapper();
//           
//            //convert json file to map
//            Map<?, ?> map = objectMapper.readValue(data, Map.class);
//           
//            List<ARE_Activity_Code_Table> sample=Entity_Layer_Activity_Code_Repository.find(map);
//            return sample;
//		}
		
		

		public String list(String data) throws JSONException {
			try {
				
				//create ObjectMapper instance
				//create ObjectMapper instance
				ObjectMapper objectMapper = new ObjectMapper();
				Gson gson=new Gson();
				JSONObject root=new JSONObject(data);
				JSONObject AREActivityCodeCheck=(JSONObject) root.get("AREActivityCode");
				JSONArray keys=AREActivityCodeCheck.names();
				JSONObject select=new JSONObject();
				List<ARE_Billing_Activity_Code_Table> list=null;
				Map<String, String> columnCode = columnCode();
				JSONObject AREActivityCode=new JSONObject();
				
				for(int i=0;i<keys.length();i++) {
					String key = (String) keys.get(i);
					
					if(AREActivityCodeCheck.get(key).equals("") || AREActivityCodeCheck.get(key).equals(null)) {
						
					}
					else if(columnCode.containsKey(key)){
						System.out.println("^^^^^^^^^^^^^^^^^"+columnCode.get(key));
						System.out.println("^^^^^^^^^^^^^^^^^"+ AREActivityCodeCheck.get(key));
						AREActivityCode.put(columnCode.get(key), AREActivityCodeCheck.get(key));
						System.out.println("^^^^^^^^^^^^^^^^^"+AREActivityCode.toString());
					}
				}
				
				
				
				
				if(AREActivityCode.length()==0) {
					list=Entity_Layer_Activity_Code_Repository.selectAll();
					
				}
				else {
					JSONArray codekeys=AREActivityCode.names();
					for(int i=0;i<codekeys.length();i++) {
						String codekey = (String) codekeys.get(i);
						select.put(codekey,AREActivityCode.get(codekey).toString());
					}
					list=Entity_Layer_Activity_Code_Repository.find(select);
				}
				
				String codelisttest = gson.toJson(list);
				System.out.println(codelisttest);
				String json="";
				JSONArray codelist=new JSONArray(list);
				int l=codelist.length();
				
				for(int i=0;i<codelist.length();i++) {
					JSONObject temp=new JSONObject(codelist.get(i));
					if(i!=codelist.length()-1)
						json+=temp.toString()+",";
					else
						json+=temp.toString();
				}
				
				
//				System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAA"+data);
//				//convert json file to map
//				Map<?, ?> newmap = objectMapper.readValue(childroot.toString(), Map.class);
//				
//				System.out.println("1:"+newmap);
//				Map<String, String> map = new HashMap<String,String>();
//				//String select = gson.toJson(newmap);
//				for(Object key : newmap.keySet())
//				{
//					if(newmap.get(key)!="" && newmap.get(key)!=null) {
//						map.put(key.toString(),newmap.get(key).toString());
//					}
//				}
//				
//
//				Map<String, String> temp = new HashMap<>();
//				temp.put("ActivityGroup","activity_group");
//				temp.put("Code","activity_code");
//				temp.put("Cost","cost");
//				temp.put("Currency","currency");
//				temp.put("Name","activity_name");
//				temp.put("TrackType","activity_track_type");
//				temp.put("TransactionType","transaction_type");
//				temp.put("UOM","unit_of_measure");
//				
//				int l=map.size();
//				System.out.println("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"+l);
//				
//				String JSON="{\n";
//				for(Object key : temp.keySet())
//				{
//					System.out.println("rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr"+temp.get(key)+"BBBB"+map.get(key));
//						if(temp.containsKey(key) && map.get(key)!="" && map.get(key)!=null){
//							if(l>1) {
//								JSON+="\""+temp.get(key)+"\": \""+map.get(key)+"\",\n";
//								System.out.println("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"+JSON);
//							}
//							else {
//								JSON+="\""+temp.get(key)+"\": \""+map.get(key)+"\"\n";
//								System.out.println("TTTTTTTTTTTTTTTTTTTTTTTTTTTT"+JSON);
//							}
//						}
//						l--;
//				}
//				
//				JSON+="}";
//				System.out.println("dadasdwasdsadasdasdasdaddadassaada"+JSON);
//				
//				Map<?, ?> list = objectMapper.readValue(JSON, Map.class);
//				
//				System.out.println("dadasdwasdsadasdasdasdaddadassaada"+JSON);
//				
//				
//				
//				System.out.println("VVVVVVVVVVVVVVVVvVVVVVVVVVVVVVVVVVVVVVVVVVV"+childroot);
//				 
//				String json = gson.toJson(sample);
//				if(codelist.length()!=1) {
//					json="{\r\n" + 
//							" \"AREActivityCodeList\":  {\r\n" + 
//							"        \"AREActivityCode\": [ "+ 
//							json+
//							" ] } \r\n" + 
//							"}";
//				}
//				else {
//					json="{\r\n" + 
//							" \"AREActivityCodeList\":  {\r\n" + 
//							"        \"AREActivityCode\":  "+ 
//							json+
//							"  } \r\n" + 
//							"}";
//				}
				json="{\r\n" + 
						" \"AREActivityCodeList\":  {\r\n" + 
						"        \"AREActivityCode\":  "+ 
						codelisttest+
						"  } \r\n" + 
						"}";
				return json;
				
				}
				catch (Exception e)
		        {
		            e.printStackTrace();
		        }
			return null;
		}
		
		public Map<String,String> columnCode()
		{
			Map<String, String> column=new HashMap<String, String>();
			column.put("ActivityGroup","activity_group");
			column.put("Code","activity_code");
			column.put("Cost","cost");
			column.put("Currency","currency");
			column.put("Name","activity_name");
			column.put("TrackType","activity_track_type");
			column.put("TransactionType","transaction_type");
			column.put("UOM","unit_of_measure");
			column.put("AREActivityCodeKey","are_activity_key");
			return column;
		}
		
		public String convert() {
			DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		    Date date = new Date();
		    String temp=dateFormat.format(date);
		    Instant instant = Instant.now();
		    Long timeStamp = new Long(instant.toEpochMilli());
		    String ts=temp+timeStamp;
		    return ts;
			}
		
		
}
