package com.example.demo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;

import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.google.gson.annotations.SerializedName;

@Table("billing_activity_detail")

public class ARE_Billing_Activity_Detail_Table {
	public ARE_Billing_Activity_Detail_Table(String activity_header_key, String activity_detail_key,
			int activity_line_no, int activity_sub_line_no, String activity_line_status, String activity_code,
			String activity_date, String service_quantity, String activity_key_data, String carrier_code,
			int reference_quantity_1, int reference_quantity_2, int reference_quantity_3,
			String reference_field_1, String reference_field_2, String reference_field_3, String ship_via, Integer cost,
			String currency, Date createts, Date modifyts, String createuserid, String modifyuserid) {
		this.activity_header_key = activity_header_key;
		this.activity_detail_key = activity_detail_key;
		this.activity_line_no = activity_line_no;
		this.activity_sub_line_no = activity_sub_line_no;
		this.activity_line_status = activity_line_status;
		this.activity_code = activity_code;
		this.activity_date = activity_date;
		this.service_quantity = service_quantity;
		this.activity_key_data = activity_key_data;
		this.carrier_code = carrier_code;
		this.reference_quantity_1 = reference_quantity_1;
		this.reference_quantity_2 = reference_quantity_2;
		this.reference_quantity_3 = reference_quantity_3;
		this.reference_field_1 = reference_field_1;
		this.reference_field_2 = reference_field_2;
		this.reference_field_3 = reference_field_3;
		this.ship_via = ship_via;
		this.cost = cost;
		this.currency = currency;
		this.createts = createts;
		this.modifyts = modifyts;
		this.createuserid = createuserid;
		this.modifyuserid = modifyuserid;
	}


	@SerializedName("AREActivityHeaderKey")
	@PrimaryKeyColumn(name = "activity_header_key", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
	private String activity_header_key;
	@SerializedName("AREActivityDetailKey")
	@PrimaryKeyColumn(name = "activity_detail_key", ordinal = 1, type = PrimaryKeyType.CLUSTERED)
	private String activity_detail_key;
	@SerializedName("ActivityLineNo")
	@Column(value="activity_line_no")
	private int activity_line_no;
	@SerializedName("ActivitySubLineNo")
	@Column(value="activity_sub_line_no")
	private int activity_sub_line_no;
	@SerializedName("Status")
	@Column(value="activity_line_status")
	private String activity_line_status;
	@SerializedName("ActivityCode")
	@Column(value="activity_code")
	private String activity_code;
	@SerializedName("ActivityDate")
	@JsonFormat(pattern="dd/MM/yyyy")
	@Column(value="activity_date")
	private String activity_date;
	@SerializedName("ServiceQty")
	@Column(value="service_quantity")
	private String service_quantity;
	@SerializedName("ActivityKeyData")
	@Column(value="activity_key_data")
	private String activity_key_data;
	@SerializedName("CarrierCode")
	@Column(value="carrier_code")
	private String carrier_code;
	@SerializedName("ReferenceQty1")
	@Column(value="reference_quantity_1")
	private int reference_quantity_1;
	@SerializedName("ReferenceQty2")
	@Column(value="reference_quantity_2")
	private int reference_quantity_2;
	@SerializedName("ReferenceQty3")
	@Column(value="reference_quantity_3")
	private int reference_quantity_3;
	@SerializedName("Referencefield1")
	@Column(value="reference_field_1")
	private String reference_field_1;
	@SerializedName("Referencefield2")
	@Column(value="reference_field_2")
	private String reference_field_2;
	@SerializedName("Referencefield3")
	@Column(value="reference_field_3")
	private String reference_field_3;
	@SerializedName("ShipVia")
	@Column(value="ship_via")
	private String ship_via;
	@SerializedName("Cost")
	@Column(value="cost")
	private Integer cost;
	@SerializedName("Currency")
	@Column(value="currency")
	private String currency;
	@SerializedName("Createts")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss.SSS")
	@Column(value="createts")
	private Date createts;
	@SerializedName("Modifyts")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss.SSS")
	@Column(value="modifyts")
	private Date modifyts;
	@SerializedName("Createuserid")
	@Column(value="createuserid")
	private String createuserid;
	@SerializedName("Modifyuserid")
	@Column(value="modifyuserid")
	private String modifyuserid;
	
	
	public ARE_Billing_Activity_Detail_Table(){}


	public String getActivity_header_key() {
		return activity_header_key;
	}


	public void setActivity_header_key(String activity_header_key) {
		this.activity_header_key = activity_header_key;
	}


	public String getActivity_detail_key() {
		return activity_detail_key;
	}


	public void setActivity_detail_key(String activity_detail_key) {
		this.activity_detail_key = activity_detail_key;
	}


	public int getActivity_line_no() {
		return activity_line_no;
	}


	public void setActivity_line_no(int activity_line_no) {
		this.activity_line_no = activity_line_no;
	}


	public int getActivity_sub_line_no() {
		return activity_sub_line_no;
	}


	public void setActivity_sub_line_no(int activity_sub_line_no) {
		this.activity_sub_line_no = activity_sub_line_no;
	}


	public String getActivity_line_status() {
		return activity_line_status;
	}


	public void setActivity_line_status(String activity_line_status) {
		this.activity_line_status = activity_line_status;
	}


	public String getActivity_code() {
		return activity_code;
	}


	public void setActivity_code(String activity_code) {
		this.activity_code = activity_code;
	}


	public String getActivity_date() {
		return activity_date;
	}


	public void setActivity_date(String activity_date) {
		this.activity_date = activity_date;
	}


	public String getService_quantity() {
		return service_quantity;
	}


	public void setService_quantity(String service_quantity) {
		this.service_quantity = service_quantity;
	}


	public String getActivity_key_data() {
		return activity_key_data;
	}


	public void setActivity_key_data(String activity_key_data) {
		this.activity_key_data = activity_key_data;
	}


	public String getCarrier_code() {
		return carrier_code;
	}


	public void setCarrier_code(String carrier_code) {
		this.carrier_code = carrier_code;
	}


	public int getReference_quantity_1() {
		return reference_quantity_1;
	}


	public void setReference_quantity_1(int reference_quantity_1) {
		this.reference_quantity_1 = reference_quantity_1;
	}


	public int getReference_quantity_2() {
		return reference_quantity_2;
	}


	public void setReference_quantity_2(int reference_quantity_2) {
		this.reference_quantity_2 = reference_quantity_2;
	}


	public int getReference_quantity_3() {
		return reference_quantity_3;
	}


	public void setReference_quantity_3(int reference_quantity_3) {
		this.reference_quantity_3 = reference_quantity_3;
	}


	public String getReference_field_1() {
		return reference_field_1;
	}


	public void setReference_field_1(String reference_field_1) {
		this.reference_field_1 = reference_field_1;
	}


	public String getReference_field_2() {
		return reference_field_2;
	}


	public void setReference_field_2(String reference_field_2) {
		this.reference_field_2 = reference_field_2;
	}


	public String getReference_field_3() {
		return reference_field_3;
	}


	public void setReference_field_3(String reference_field_3) {
		this.reference_field_3 = reference_field_3;
	}


	public String getShip_via() {
		return ship_via;
	}


	public void setShip_via(String ship_via) {
		this.ship_via = ship_via;
	}


	public Integer getCost() {
		return cost;
	}


	public void setCost(Integer cost) {
		this.cost = cost;
	}


	public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public Date getCreatets() {
		return createts;
	}


	public void setCreatets(Date createts) {
		this.createts = createts;
	}


	public Date getModifyts() {
		return modifyts;
	}


	public void setModifyts(Date modifyts) {
		this.modifyts = modifyts;
	}


	public String getCreateuserid() {
		return createuserid;
	}


	public void setCreateuserid(String createuserid) {
		this.createuserid = createuserid;
	}


	public String getModifyuserid() {
		return modifyuserid;
	}


	public void setModifyuserid(String modifyuserid) {
		this.modifyuserid = modifyuserid;
	}
	
	public String convert() {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
	    Date date = new Date();
	    String temp=dateFormat.format(date);
	    Instant instant = Instant.now();
	    Long timeStamp = new Long(instant.toEpochMilli());
	    String ts=temp+timeStamp;
	    return ts;
		}
	
}

