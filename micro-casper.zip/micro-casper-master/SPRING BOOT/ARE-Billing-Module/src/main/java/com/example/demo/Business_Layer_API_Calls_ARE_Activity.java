package com.example.demo;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


//import com.example.entity.layer.BussinessLayerTableDetails;

@RestController
@RequestMapping("/AREBillingActivity")
public class Business_Layer_API_Calls_ARE_Activity extends Entity_Controller{
	
		@Autowired
		private Business_Layer_ARE_Activity service;
		
		@RequestMapping(value="/manage", method = RequestMethod.POST, produces = "application/json")
		public ResponseEntity<Object> manage(@RequestBody String data) throws JSONException{
			System.out.println("*****************************************"+data);
			String result=service.manage(data);
			return new ResponseEntity<>(result, HttpStatus.OK);
		}
		
		@RequestMapping(value = "/list", method = RequestMethod.POST, produces = "application/json")
		public ResponseEntity<Object> list(@RequestBody String data) throws JSONException {
			System.out.println("*****************************************"+data);
			String list=service.list(data);
		return new ResponseEntity<>(list, HttpStatus.OK);
		}	    
		
}

@RestController
@RequestMapping("/AREBillingActivityCode")
class Bussiness_Layer_API_Calls_ARE_Activity_Code extends Entity_Controller{
	
		@Autowired
		private Business_Layer_ARE_Activity_Code service;
		
		@RequestMapping(value="/manage", method = RequestMethod.POST, produces = "application/json")
		public ResponseEntity<Object> manage(@RequestBody String data) throws JSONException{
			System.out.println("AAAAAAAAAAAAAAAAAAAA*******************"+data);
			String result=service.manage(data);
			return new ResponseEntity<>(result, HttpStatus.OK);
		}
		
		@RequestMapping(value = "/list", method = RequestMethod.POST, produces = "application/json")
			public ResponseEntity<Object> list(@RequestBody String data) throws JSONException {
			System.out.println("*****************************************"+data);
			String list=service.list(data);
			return new ResponseEntity<>(list, HttpStatus.OK);
		}
		    
		
}

